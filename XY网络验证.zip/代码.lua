XY网络验证1.0
安装代码：
pkg update -y && pkg upgrade -y && pkg install -y git curl wget gh nano vim findutils coreutils && termux-setup-storage && curl -o ~/kami.sh https://raw.githubusercontent.com/xuwuyyds/ljbc/main/kami.sh && chmod +x ~/kami.sh && mv ~/kami.sh /data/user/0/com.termux/files/usr/bin/kami && chmod 777 /data/user/0/com.termux/files/usr/bin/kami && echo "✅ 安装完成！输入 kami 运行"
请下载termux后输入代码即可使用